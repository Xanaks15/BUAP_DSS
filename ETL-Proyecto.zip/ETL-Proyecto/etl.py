import os
import warnings
from typing import Dict, Tuple

import numpy as np  # Librería para cálculos numéricos
import pandas as pd  # Librería para manejar datos en tablas (DataFrames)
import time

# Se intenta usar SQLAlchemy para conectar con MySQL (opción más moderna y limpia).
# Si no está disponible, se usa el conector nativo mysql.connector.
try:
    import sqlalchemy
    from sqlalchemy import create_engine
except ImportError:
    sqlalchemy = None
    create_engine = None

try:
    import mysql.connector
except ModuleNotFoundError:
    mysql = None

# Evita mostrar advertencias de conexión
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    message="pandas only supports SQLAlchemy connectable"
)

# ==========================================================
# FUNCIONES PRINCIPALES DEL ETL
# ==========================================================

def load_sql_queries(file_path: str) -> Dict[str, str]:
    """
    Lee un archivo .sql que contiene varias consultas separadas por etiquetas tipo '-- nombre_query'.
    Devuelve un diccionario donde las llaves son los nombres y los valores son las consultas SQL completas.

    Parámetros:
        file_path (str): Ruta al archivo .sql dentro de la carpeta sql_queries.

    Retorna:
        dict: Un diccionario con las consultas SQL, donde cada nombre está asociado a su consulta completa.
    """
    queries: Dict[str, str] = {}
    current_name: str | None = None
    buffer: list[str] = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            stripped = line.strip()
            # Si la línea comienza con '--', indica una nueva consulta
            if stripped.startswith('--'):
                # Guarda la consulta anterior antes de comenzar una nueva
                if current_name is not None:
                    queries[current_name] = '\n'.join(buffer).strip()
                    buffer.clear()
                # Extrae el nombre de la consulta (después de '--')
                current_name = stripped[2:].strip()
            else:
                buffer.append(line.rstrip('\n'))
        # Guarda la última consulta encontrada
        if current_name is not None:
            queries[current_name] = '\n'.join(buffer).strip()
    return queries


def extract_data(config: Dict[str, str], queries: Dict[str, str]) -> Dict[str, pd.DataFrame]:
    """
    Realiza la extracción de datos desde la base de datos fuente (PMO_DB).
    Usa las consultas SQL del archivo extraction_queries.sql que se encuentra en la carpeta sql_queries.

    Parámetros:
        config (dict): Diccionario con credenciales y configuración de conexión a la base de datos.
        queries (dict): Diccionario con las consultas SQL cargadas desde el archivo .sql.

    Retorna:
        dict: Contiene varios DataFrames, cada uno con los datos extraídos (proyectos, tareas, empleados, etc.).
    """
    use_sqlalchemy = sqlalchemy is not None and create_engine is not None
    connection = None
    engine = None
    try:
        # Se conecta a la base de datos PMO usando SQLAlchemy o mysql.connector
        if use_sqlalchemy:
            user = config.get('user')
            password = config.get('password')
            host = config.get('host')
            database = config.get('database')
            engine_url = f"mysql+mysqlconnector://{user}:{password}@{host}/{database}"
            engine = create_engine(engine_url)
            conn_for_sql = engine
        else:
            if mysql is None:
                raise ImportError(
                    "No se encontró ni SQLAlchemy ni mysql-connector. "
                    "Instala una de estas dependencias para continuar."
                )
            connection = mysql.connector.connect(**config)
            conn_for_sql = connection

        # Relaciona los nombres de consulta con las tablas destino
        mapping = {
            'extract_projects': 'projects',
            'extract_tasks': 'tasks',
            'extract_project_employees': 'project_employees',
            'extract_states': 'states',
            'extract_types': 'types',
            'extract_finances': 'finances',
            'extract_catalogues': 'catalogues',
        }

        # Ejecuta cada consulta SQL y guarda los resultados en DataFrames
        tables: Dict[str, pd.DataFrame] = {}
        for query_name, dest_key in mapping.items():
            sql = queries.get(query_name)
            if sql is None:
                raise KeyError(f"Query '{query_name}' not found in extraction queries file.")
            tables[dest_key] = pd.read_sql(sql, conn_for_sql)

        return tables
    finally:
        # Cierra la conexión abierta
        if connection is not None:
            try:
                if hasattr(connection, 'is_connected') and connection.is_connected():
                    connection.close()
            except Exception:
                pass
        if engine is not None:
            try:
                engine.dispose()
            except Exception:
                pass


def _calculate_task_metrics(tasks: pd.DataFrame, project_row: pd.Series) -> Tuple[int, int, int]:
    """
    Calcula cuántas tareas están planificadas, completadas y retrasadas para un proyecto dado.

    Parámetros:
        tasks (DataFrame): Tabla de todas las tareas extraídas.
        project_row (Series): Una fila con la información del proyecto actual.

    Retorna:
        tuple: (total_tareas, tareas_completadas, tareas_retrasadas)
    """
    project_tasks = tasks.loc[tasks['catalogo_tareas_id'] == project_row['catalogo_id']]
    total = len(project_tasks)
    completed = int(project_tasks['completada'].sum())
    delay_count = 0

    # Revisa si hay tareas entregadas tarde o sin completar en tiempo
    for _, t in project_tasks.iterrows():
        entrega = t.get('fecha_entrega')
        completado = t.get('fecha_completado')
        finished = bool(t.get('completada'))
        if finished and pd.notnull(entrega) and pd.notnull(completado):
            if pd.to_datetime(completado) > pd.to_datetime(entrega):
                delay_count += 1
            continue
        if not finished and pd.notnull(entrega) and pd.notnull(project_row.get('fecha_fin_real')):
            if pd.to_datetime(entrega) <= pd.to_datetime(project_row['fecha_fin_real']):
                delay_count += 1
    return total, completed, delay_count


def transform_data(tables: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Transforma los datos extraídos para generar las tablas finales de dimensiones y hechos del Data Warehouse (SSD).

    Parámetros:
        tables (dict): Diccionario con los DataFrames obtenidos en la extracción.

    Retorna:
        tuple: Contiene los DataFrames transformados (tabla de hechos + dimensiones).
    """
    # Copias de los datos extraídos
    projects = tables['projects'].copy()
    tasks = tables['tasks'].copy()
    project_employees = tables['project_employees'].copy()
    states = tables['states'].copy()
    types = tables['types'].copy()
    finances = tables['finances'].copy()


    # Combina información de estados, tipos y finanzas con los proyectos
    projects = projects.merge(states, on='estado_id', how='left')
    projects = projects.merge(types.rename(columns={'nombre': 'tipo_proyecto_nombre'}), on='tipo_proyecto_id', how='left')
    projects = projects.merge(finances, on='proyecto_id', how='left')

    # Filtra solo proyectos completados o cancelados
    qualifying_states = ['completado', 'cancelado']
    projects['_estado_normalizado'] = projects['nombre_estado'].astype(str).str.strip().str.lower()
    filtered_projects = projects[projects['_estado_normalizado'].isin(qualifying_states)].copy()
    filtered_projects.drop(columns=['_estado_normalizado'], inplace=True)

    # Calcula métricas de tareas para cada proyecto
    metrics_list = []
    for idx, row in filtered_projects.iterrows():
        t_plan, t_comp, t_delay = _calculate_task_metrics(tasks, row)
        metrics_list.append((t_plan, t_comp, t_delay))
    metrics_df = pd.DataFrame(
        metrics_list,
        columns=['tareas_planificadas', 'tareas_completadas', 'tareas_retrasadas'],
        index=filtered_projects.index
    )
    filtered_projects = pd.concat([filtered_projects, metrics_df], axis=1)
    emp_counts = (
        project_employees
        .groupby('proyecto_id')['empleado_id']
        .nunique()
        .reset_index()
    )

    # Calcula número de empleados asignados a cada proyecto
    emp_counts.rename(columns={'empleado_id': 'empleados_asignados'}, inplace=True)
    filtered_projects = filtered_projects.merge(emp_counts, on='proyecto_id', how='left')
    filtered_projects['empleados_asignados'] = filtered_projects['empleados_asignados'].fillna(0).astype(int)

    # Limpia y calcula métricas financieras
    filtered_projects.rename(columns={
        'monto_presupuestado': 'monto_planificado',
        'monto_real_acumulado': 'monto_real',
        'ingreso_proyecto': 'ingreso_proyecto'
    }, inplace=True)
    for col in ['horas_planificadas', 'horas_trabajadas', 'monto_planificado', 'monto_real', 'ingreso_proyecto']:
        filtered_projects[col] = filtered_projects[col].fillna(0)

    # Calcula ganancia y ROI
    filtered_projects['ganancia_proyecto'] = (
        filtered_projects['ingreso_proyecto'] - filtered_projects['monto_real']
    )
    filtered_projects['roi'] = np.where(
        filtered_projects['monto_real'] > 0,
        (filtered_projects['ganancia_proyecto'] / filtered_projects['monto_real']) * 100,
        0.0
    )

    # Calcula TUCT (duración del proyecto en días)
    def compute_tuct(row: pd.Series) -> float:
        try:
            start = pd.to_datetime(row['fecha_inicio_plan'])
            end = pd.to_datetime(row['fecha_fin_real'])
            if pd.isnull(start) or pd.isnull(end):
                return 0.0
            days = (end - start).days
            return float(days) if days >= 0 else 0.0
        except Exception:
            return 0.0
    filtered_projects['tuct'] = filtered_projects.apply(compute_tuct, axis=1)

    # Crea las dimensiones de fecha, mes, día, año y tiempo
    date_cols = ['fecha_inicio_plan', 'fecha_fin_plan', 'fecha_inicio_real', 'fecha_fin_real']
    all_dates = pd.unique(filtered_projects[date_cols].values.ravel('K'))
    all_dates = pd.to_datetime([d for d in all_dates if pd.notnull(d)])
    all_dates = pd.Index(all_dates).drop_duplicates().sort_values()
    dias_esp = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']
    meses_esp = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
    date_info = pd.DataFrame({
        'fecha': all_dates,
        'anio': all_dates.year,
        'mes': all_dates.month,
        'dia': all_dates.day,
        'nombre_dia': [dias_esp[d] for d in all_dates.weekday],
        'nombre_mes': [meses_esp[m - 1] for m in all_dates.month],
        'trimestre': all_dates.quarter,
    })
    dim_anio_df = (
        date_info[['anio']]
        .drop_duplicates()
        .sort_values('anio')
        .reset_index(drop=True)
    )
    dim_anio_df['anio_id'] = dim_anio_df.index + 1
    dim_mes_df = (
        date_info[['anio', 'mes', 'nombre_mes', 'trimestre']]
        .drop_duplicates()
        .sort_values(['anio', 'mes'])
        .reset_index(drop=True)
    )
    dim_mes_df = dim_mes_df.merge(dim_anio_df, on='anio', how='left')
    dim_mes_df['mes_id'] = dim_mes_df.index + 1
    dim_mes_df['numero_mes'] = dim_mes_df['mes']
    dim_dia_df = (
        date_info[['anio', 'mes', 'dia', 'nombre_dia']]
        .drop_duplicates()
        .sort_values(['anio', 'mes', 'dia'])
        .reset_index(drop=True)
    )
    dim_dia_df = dim_dia_df.merge(dim_mes_df[['anio', 'mes', 'mes_id']], on=['anio', 'mes'], how='left')
    dim_dia_df['dia_id'] = dim_dia_df.index + 1
    dim_tiempo_df = date_info[['fecha', 'anio', 'mes', 'dia']].copy()
    dim_tiempo_df = dim_tiempo_df.merge(dim_dia_df[['anio', 'mes', 'dia', 'dia_id']], on=['anio', 'mes', 'dia'], how='left')
    dim_tiempo_df = dim_tiempo_df[['fecha', 'dia_id']].drop_duplicates().reset_index(drop=True)
    dim_tiempo_df['tiempo_id'] = dim_tiempo_df.index + 1
    tiempo_lookup = dim_tiempo_df.set_index('fecha')['tiempo_id'].to_dict()
    def lookup_tiempo_id(date_value):
        if pd.isnull(date_value):
            return np.nan
        dt = pd.to_datetime(date_value)
        return tiempo_lookup.get(dt, np.nan)
    filtered_projects['fecha_inicio_plan_id'] = filtered_projects['fecha_inicio_plan'].apply(lookup_tiempo_id).astype('Float64')
    filtered_projects['fecha_fin_plan_id'] = filtered_projects['fecha_fin_plan'].apply(lookup_tiempo_id).astype('Float64')
    filtered_projects['fecha_inicio_real_id'] = filtered_projects['fecha_inicio_real'].apply(lookup_tiempo_id).astype('Float64')
    filtered_projects['fecha_fin_real_id'] = filtered_projects['fecha_fin_real'].apply(lookup_tiempo_id).astype('Float64')
    fallback_id = 1
    if not dim_tiempo_df.empty:
        fallback_id = int(dim_tiempo_df['tiempo_id'].min())
    def fill_date_ids(row: pd.Series, col_name: str) -> int:
        val = row[col_name]
        if pd.notnull(val):
            return int(val)
        for candidate in ['fecha_fin_real_id', 'fecha_fin_plan_id', 'fecha_inicio_real_id', 'fecha_inicio_plan_id']:
            cval = row[candidate]
            if pd.notnull(cval):
                return int(cval)
        return fallback_id
    for col in ['fecha_inicio_plan_id', 'fecha_fin_plan_id', 'fecha_inicio_real_id', 'fecha_fin_real_id']:
        filtered_projects[col] = filtered_projects.apply(lambda r: fill_date_ids(r, col), axis=1)
    dim_estado_df = states[states['nombre_estado'].astype(str).str.strip().str.lower().isin(qualifying_states)].copy()
    dim_tipo_proyecto_df = types.rename(columns={'nombre': 'nombre_tipo'})
    fact_df = filtered_projects[[
        'proyecto_id',
        'nombre',
        'descripcion',
        'horas_planificadas',
        'horas_trabajadas',
        'monto_planificado',
        'monto_real',
        'ganancia_proyecto',
        'tareas_planificadas',
        'tareas_completadas',
        'tareas_retrasadas',
        'empleados_asignados',
        'roi',
        'tuct',
        'fecha_inicio_plan_id',
        'fecha_fin_plan_id',
        'fecha_inicio_real_id',
        'fecha_fin_real_id',
        'estado_id',
        'tipo_proyecto_id'
    ]].copy()
    fact_df.rename(columns={
        'proyecto_id': 'fact_id',
        'fecha_inicio_plan_id': 'fecha_inicio_plan',
        'fecha_fin_plan_id': 'fecha_fin_plan',
        'fecha_inicio_real_id': 'fecha_inicio_real',
        'fecha_fin_real_id': 'fecha_fin_real'
    }, inplace=True)
    numeric_columns = [
        'horas_planificadas', 'horas_trabajadas', 'monto_planificado', 'monto_real',
        'ganancia_proyecto', 'tareas_planificadas', 'tareas_completadas',
        'tareas_retrasadas', 'empleados_asignados', 'roi', 'tuct'
    ]
    for col in numeric_columns:
        fact_df[col] = fact_df[col].fillna(0)
    fact_df['roi'] = fact_df['roi'].astype(float)
    fact_df['tuct'] = fact_df['tuct'].astype(float)
    id_columns = [
        'fact_id', 'fecha_inicio_plan', 'fecha_fin_plan', 'fecha_inicio_real',
        'fecha_fin_real', 'estado_id', 'tipo_proyecto_id'
    ]
    for col in id_columns:
        fact_df[col] = fact_df[col].astype(int)
    return (
        fact_df,
        dim_estado_df[['estado_id', 'nombre_estado']],
        dim_tipo_proyecto_df[['tipo_proyecto_id', 'nombre_tipo']],
        dim_tiempo_df[['tiempo_id', 'fecha', 'dia_id']],
        dim_dia_df[['dia_id', 'nombre_dia', 'dia', 'mes_id']],
        dim_mes_df[['mes_id', 'nombre_mes', 'numero_mes', 'trimestre', 'anio_id']],
        dim_anio_df[['anio_id', 'anio']]
    )


def _coerce_for_mysql(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convierte los tipos de datos de pandas a tipos compatibles con MySQL (int, float, str, date, bool).
    """
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = pd.to_datetime(out[col], errors="coerce").dt.date
    out = out.where(out.notnull(), None)
    def to_python_scalar(x):
        if x is None:
            return None
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            return float(x)
        if isinstance(x, (np.bool_,)):
            return bool(x)
        return x
    for col in out.columns:
        out[col] = out[col].map(to_python_scalar)
    return out.astype(object)


def _parse_insert_columns(sql: str) -> list[str]:
    """
    Extrae la lista de columnas que aparecen en un comando INSERT dentro del archivo .sql.

    Parámetro:
        sql (str): La consulta SQL completa.

    Retorna:
        list: Lista de nombres de columnas que aparecen en el INSERT.
    """
    upper = sql.upper()
    insert_pos = upper.find('INSERT INTO') if 'INSERT INTO' in upper else upper.find('INSERT IGNORE INTO')
    if insert_pos == -1:
        raise ValueError("The provided SQL does not contain 'INSERT INTO'")

    open_paren = sql.find('(', insert_pos)
    if open_paren == -1:
        raise ValueError("Cannot find opening parenthesis in INSERT statement")

    close_paren = sql.find(')', open_paren)
    if close_paren == -1:
        raise ValueError("Cannot find closing parenthesis in INSERT statement")
    columns_part = sql[open_paren + 1:close_paren]
    columns = [c.strip() for c in columns_part.replace('\n', ' ').split(',')]
    return columns


def insert_dataframe(conn: any, df: pd.DataFrame, sql: str) -> None:
    """
    Inserta los datos de un DataFrame en la base de datos SSD utilizando una consulta SQL de tipo INSERT.

    Parámetros:
        conn: Conexión abierta a la base de datos SSD.
        df (DataFrame): Datos a insertar.
        sql (str): Consulta SQL con placeholders (%s) cargada desde load_queries.sql.
    """
    if df.empty:
        return
    cursor = conn.cursor()

    cursor.execute("USE ssd_db;")
    df_coerced = _coerce_for_mysql(df)
    columns = _parse_insert_columns(sql)
    try:
        df_ordered = df_coerced[columns]
    except KeyError as e:
        missing = set(columns) - set(df_coerced.columns)
        raise KeyError(f"Columns {missing} not found in DataFrame for insertion.") from e
    data = [tuple(row) for row in df_ordered.to_numpy(dtype=object)]
    cursor.executemany(sql, data)
    conn.commit()

def main() -> None:
    """
    Función principal del ETL.
    1. Carga las consultas SQL desde la carpeta sql_queries.
    2. Se conecta a las bases de datos PMO (origen) y SSD (destino).
    3. Ejecuta la extracción, transformación y carga de datos.
    4. Mide el tiempo de ejecución de cada etapa (extracción, transformación y carga).
    """
    # Configuración de conexión para la base PMO (origen)
    pmo_config: Dict[str, str] = {
        'user': 'pmo_remote',
        'password': 'Clave_PMO_Remote',
        'host': 'localhost', # Si es una prueba local: localhost. Si es una prueba remota: IP del PMO.
        'database': 'pmo_db',
        'raise_on_warnings': True
    }
    # Configuración de conexión para la base SSD (destino)
    ssd_config: Dict[str, str] = {
        'user': 'ssd_remote',
        'password': 'Clave_SSD_Remote',
        'host': 'localhost', # Si es una prueba local: localhost. Si es una prueba remota: IP del SSD.
        'database': 'ssd_db',
        'raise_on_warnings': False
    }
    if mysql is None:
        raise ImportError(
            "El módulo mysql-connector-python no está instalado. "
            "Ejecuta 'pip install mysql-connector-python' antes de continuar."
        )

    # Carga los archivos SQL desde la carpeta sql_queries
    base_dir = os.path.dirname(os.path.abspath(__file__))
    extraction_file = os.path.join(base_dir, 'sql_queries', 'extraction_queries.sql')
    load_file = os.path.join(base_dir, 'sql_queries', 'load_queries.sql')
    extraction_queries = load_sql_queries(extraction_file)
    load_queries = load_sql_queries(load_file)

    # EXTRACCIÓN
    print('Extrayendo datos de la base de datos PMO...')
    inicio_extraccion = time.time()
    tables = extract_data(pmo_config, extraction_queries)
    fin_extraccion = time.time()
    duracion_extraccion = fin_extraccion - inicio_extraccion
    print(f'Extracción completada en {duracion_extraccion:.2f} segundos.')

    # TRANSFORMACIÓN
    print('Transformando datos...')
    inicio_transformacion = time.time()
    (
        fact_df,
        dim_estado_df,
        dim_tipo_proyecto_df,
        dim_tiempo_df,
        dim_dia_df,
        dim_mes_df,
        dim_anio_df
    ) = transform_data(tables)
    fin_transformacion = time.time()
    duracion_transformacion = fin_transformacion - inicio_transformacion
    print(f'Transformación completada en {duracion_transformacion:.2f} segundos.')

    # CARGA
    print('Cargando datos a la base de datos SSD...')
    inicio_carga = time.time()
    ssd_conn = mysql.connector.connect(**ssd_config)
    try:
        # Inserta cada dimensión y la tabla de hechos usando las consultas del archivo load_queries.sql
        insert_dataframe(ssd_conn, dim_anio_df[['anio_id', 'anio']], load_queries['load_dim_anio'])
        insert_dataframe(ssd_conn, dim_mes_df[['mes_id', 'nombre_mes', 'numero_mes', 'trimestre', 'anio_id']], load_queries['load_dim_mes'])

        # Ajusta el nombre de la columna antes de cargar la dimensión día
        dim_dia_for_load = dim_dia_df.copy().rename(columns={'dia': 'numero_dia'})
        insert_dataframe(ssd_conn, dim_dia_for_load[['dia_id', 'nombre_dia', 'numero_dia', 'mes_id']], load_queries['load_dim_dia'])

        insert_dataframe(ssd_conn, dim_tiempo_df[['tiempo_id', 'fecha', 'dia_id']], load_queries['load_dim_tiempo'])
        insert_dataframe(ssd_conn, dim_estado_df[['estado_id', 'nombre_estado']], load_queries['load_dim_estado'])

        dim_tipo_for_load = dim_tipo_proyecto_df.copy().rename(columns={'nombre_tipo': 'nombre'})
        insert_dataframe(ssd_conn, dim_tipo_for_load[['tipo_proyecto_id', 'nombre']], load_queries['load_dim_tipo_proyecto'])

        insert_dataframe(
            ssd_conn,
            fact_df[[
                'fact_id', 'nombre', 'descripcion', 'horas_planificadas', 'horas_trabajadas',
                'monto_planificado', 'monto_real', 'ganancia_proyecto', 'tareas_planificadas',
                'tareas_completadas', 'tareas_retrasadas', 'empleados_asignados', 'roi', 'tuct',
                'fecha_inicio_plan', 'fecha_fin_plan', 'fecha_inicio_real', 'fecha_fin_real',
                'estado_id', 'tipo_proyecto_id'
            ]],
            load_queries['load_fact_proyecto']
        )
        fin_carga = time.time()
        duracion_carga = fin_carga - inicio_carga
        print(f'Carga completa en {duracion_carga:.2f} segundos.')
    finally:
        if ssd_conn.is_connected():
            ssd_conn.close()

    # MÉTRICAS FINALES
    tiempo_total = duracion_extraccion + duracion_transformacion + duracion_carga
    print("------------------------------------------------------------")
    print("MÉTRICAS DE EJECUCIÓN DEL ETL")
    print(f"Tiempo de extracción:      {duracion_extraccion:.2f} segundos")
    print(f"Tiempo de transformación:  {duracion_transformacion:.2f} segundos")
    print(f"Tiempo de carga:           {duracion_carga:.2f} segundos")
    print(f"Tiempo total del ETL:      {tiempo_total:.2f} segundos")
    print("------------------------------------------------------------")

if __name__ == '__main__':
    main()