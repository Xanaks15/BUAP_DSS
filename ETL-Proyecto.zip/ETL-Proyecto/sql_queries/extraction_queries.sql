-- extract_projects
SELECT p.proyecto_id,
       p.nombre,
       p.descripcion,
       p.fecha_inicio_plan,
       p.fecha_fin_plan,
       p.fecha_inicio_real,
       p.fecha_fin_real,
       p.horas_planificadas,
       p.horas_trabajadas,
       p.estado_id,
       p.tipo_proyecto_id,
       p.cliente_id,
       p.catalogo_id
FROM proyecto AS p;

-- extract_tasks
SELECT t.tarea_id,
       t.nombre_tarea,
       t.tipo_tarea,
       t.prioridad,
       t.completada,
       t.fecha_entrega,
       t.fecha_completado,
       t.catalogo_tareas_id
FROM tarea AS t;

-- extract_project_employees
SELECT pe.proyecto_id,
       pe.empleado_id
FROM proyecto_empleado AS pe;

-- extract_states
SELECT estado_id,
       nombre_estado
FROM estado;

-- extract_types
SELECT tipo_proyecto_id,
       nombre
FROM tipo_proyecto;

-- extract_finances
SELECT proyecto_id,
       monto_presupuestado,
       monto_real_acumulado,
       ingreso_proyecto
FROM finanzas_proyecto;

-- extract_catalogues
SELECT catalogo_id,
       nombre_catalogo
FROM catalogo_tareas;